Jun<html>
  <header>
    <title>Weekly Status report</title>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
  </header>
  <?php

  $link = mysql_connect('69.73.138.187', 'bahabin_sa', 'vct2025') or die('Could not connect: ' . mysql_error());
      $db1 = @mysql_select_db('bahabin_bugtracker') or die('Could not select database');
      
     
      ?>
      </form>
      </body>
      </html>