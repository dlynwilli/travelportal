<?php

/*
 * Create an empty array to store constants
 */
$C = array();

/*
 * The database host URL
 */
$C['DB_HOST'] = 'localhost';

/*
 * The database username
 */
$C['DB_USER'] = 'admin';

/*
 * The database password
 */
$C['DB_PASS'] = 'adminpw';

/*
 * The name of the database to work with
 */
$C['DB_NAME'] = 'mytestdb';

?>